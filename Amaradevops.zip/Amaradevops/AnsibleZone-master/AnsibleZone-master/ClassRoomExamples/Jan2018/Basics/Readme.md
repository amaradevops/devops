1. Find out manual process
2. Convert each step into task