echo "Updating packages"
sudo apt-get update 
echo "Installing nginx"
sudo apt-get install nginx -y