echo "Updating packages"
sudo apt-get update 
echo "Installing nginx"
sudo apt-get install apache2 -y