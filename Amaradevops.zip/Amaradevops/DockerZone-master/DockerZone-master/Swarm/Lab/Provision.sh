apt-get update
wget -qO- https://get.docker.com/ | sh